import React from 'react'

function Contacts() {
  return (
    <div>
      Like what you see?
      Hire me!
    </div>
  )
}

export default Contacts
