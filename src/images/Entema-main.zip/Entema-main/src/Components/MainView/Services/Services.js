import React from 'react'

function Services() {
  return (
    <div>
      Need help with your next project?
      Get in Touch!
    </div>
  )
}

export default Services
