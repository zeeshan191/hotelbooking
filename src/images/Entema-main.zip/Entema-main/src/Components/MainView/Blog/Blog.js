import React from 'react'

function Blog() {
  return (
    <div>
      Daily blogs
    </div>
  )
}

export default Blog

