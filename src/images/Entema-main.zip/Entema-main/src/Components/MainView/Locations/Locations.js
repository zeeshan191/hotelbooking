import React from 'react'

function Locations() {
  return (
    <div>
      Check out all of our reponsive offices across beautiful US!
    </div>
  )
}

export default Locations
