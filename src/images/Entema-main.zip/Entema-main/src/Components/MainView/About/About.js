import React from 'react'

function About() {
  return (
    <div>
      While working on a recent project I realized a need for a responsive, customizeable sidebar.
      I did not find any good examples online so I decided to learn how to biuld one!
    </div>
  )
}

export default About

